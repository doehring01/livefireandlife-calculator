# FI Take-Home Pay Calculator (MVP)

A Pen created on CodePen.

Original URL: [https://codepen.io/doehring01/pen/myeeJQr](https://codepen.io/doehring01/pen/myeeJQr).

